from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import torch, shutil, os, uuid

from model import load_model
from predict import predict_image

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
MODEL_PATH = "models/NeuroScan_AI_model.pth"
model, classes = load_model(MODEL_PATH, device)
print("Loaded classes:", classes)

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    ext = file.filename.split(".")[-1]
    temp_path = os.path.join(UPLOAD_DIR, f"{uuid.uuid4()}.{ext}")

    with open(temp_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    label, confidence, probabilities = predict_image(temp_path, model, classes, device)
    os.remove(temp_path)

    return {"prediction": label, "confidence": confidence, "probabilities": probabilities}

app.mount("/", StaticFiles(directory="../frontend", html=True), name="frontend")