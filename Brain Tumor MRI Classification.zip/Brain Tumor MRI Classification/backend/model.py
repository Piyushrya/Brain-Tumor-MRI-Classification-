import torch
import torch.nn as nn

class BrainTumorCNN(nn.Module):
    def __init__(self,num_classes=4):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3,32,3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32,64,3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(64,128,3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(128,256,3, padding=1),nn.ReLU(), nn.MaxPool2d(2),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(256 * 14 * 14, 256),
            nn.ReLU(),
            nn.Dropout(0.6),
            nn.Linear(256, num_classes)
        )

    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x

def load_model(model_path,device):
    checkpoint = torch.load(model_path,map_location=device)
    classes = checkpoint["classes"]
    model = BrainTumorCNN(num_classes=len(classes)).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    return model, classes