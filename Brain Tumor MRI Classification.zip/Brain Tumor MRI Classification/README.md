# Brain Tumor MRI Classifier

A deep learning project for classifying brain MRI images into **Glioma, Meningioma, No Tumor, and Pituitary Tumor** using a custom CNN built with **PyTorch**.

## Overview

* **Framework:** PyTorch
* **Task:** Multi-class Image Classification
* **Input Size:** 224 × 224 RGB
* **Training Images:** 5,600
* **Testing Images:** 1,600
* **Classes:** 4
* **Test Accuracy:** 94.56%

## Model Architecture

```text
Input Image
224 × 224 × 3
      │
      ▼
Conv2D (3 → 32) + ReLU + MaxPool
      │
      ▼
Conv2D (32 → 64) + ReLU + MaxPool
      │
      ▼
Conv2D (64 → 128) + ReLU + MaxPool
      │
      ▼
Conv2D (128 → 256) + ReLU + MaxPool
      │
      ▼
Flatten
      │
      ▼
Linear (50176 → 256) + ReLU
      │
      ▼
Dropout (0.6)
      │
      ▼
Linear (256 → 4)
      │
      ▼
Prediction
```

## Data Preprocessing

* Resize images to **224 × 224**
* Random horizontal flip
* Random rotation
* Random affine transformation
* Brightness and contrast adjustment
* Convert images to tensors
* ImageNet normalization

## Training

* **Optimizer:** Adam
* **Learning Rate:** `1e-4`
* **Weight Decay:** `1e-4`
* **Loss:** Cross Entropy Loss
* **Epochs:** 80
* **Batch Size:** 32
* **Scheduler:** ReduceLROnPlateau

## Results

| Metric            |      Score |
| ----------------- | ---------: |
| Training Accuracy |     99.07% |
| Test Accuracy     | **94.56%** |
| Weighted F1-Score |   **0.94** |

### Classes

* Glioma
* Meningioma
* No Tumor
* Pituitary

The model is also evaluated using a **classification report** and **confusion matrix**.

## Prediction

The trained model can predict a new MRI image and return:

```text
Prediction: meningioma
Confidence: 99.99%
```

## Project Structure

```text
brain-tumor-mri-classifier/
│
├── MRI-Brain-Tumor-Classifier.ipynb
├── README.md
├── requirements.txt
└── models/
    └── NeuroScan_AI_model.pth
```

## Dataset

Brain Tumor MRI Dataset containing four classes:

`glioma` · `meningioma` · `notumor` · `pituitary`

## Disclaimer

This project is developed for **educational and research purposes only**. It is not intended to provide medical diagnosis or replace professional medical advice.
